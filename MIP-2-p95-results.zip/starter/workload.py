"""Одна операция в двух конфигурациях. Результат обязан совпадать."""
import hashlib

def transform(value, rounds):
    data = str(value).encode("ascii")
    for _ in range(rounds):
        data = hashlib.sha256(data).digest()
    return int.from_bytes(data[:8], "big")

def process(values, mode, rounds):
    if mode not in ("A", "B"):
        raise ValueError("mode должен быть A или B")
    cache = {}
    total = 0
    for value in values:
        if mode == "B" and value in cache:
            result = cache[value]
        else:
            result = transform(value, rounds)
            if mode == "B":
                cache[value] = result
        total = (total + result) % (1 << 64)
    return f"{total:016x}"
