"""Реальные локальные измерения subprocess; никаких заранее заданных времён."""
import argparse
import csv
import hashlib
import json
import os
import platform
import random
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from starter.workload import process

ROOT = Path(__file__).resolve().parent
FIELDS = ["attempt", "phase", "mode", "repeat", "status", "duration_ms",
          "observed_wait_ms", "timeout_ms", "injected_delay_ms", "result", "error"]

def once(command, timeout_ms):
    start = time.perf_counter_ns()
    try:
        proc = subprocess.run(command, capture_output=True, text=True,
                              encoding="utf-8", timeout=timeout_ms / 1000,
                              check=False)
        elapsed = (time.perf_counter_ns() - start) / 1e6
        if proc.returncode:
            return "error", "", elapsed, "", proc.stderr.strip()[:200]
        result = json.loads(proc.stdout)["result"]
        return "ok", elapsed, elapsed, result, ""
    except subprocess.TimeoutExpired:
        elapsed = (time.perf_counter_ns() - start) / 1e6
        return "timeout", "", elapsed, "", "deadline exceeded; child killed and waited"
    except (OSError, ValueError, KeyError) as exc:
        elapsed = (time.perf_counter_ns() - start) / 1e6
        return "error", "", elapsed, "", str(exc)[:200]

def main():
    p = argparse.ArgumentParser(description="Собственный замер: конфигурация × повтор")
    p.add_argument("--mode", choices=("A", "B"), required=True)
    p.add_argument("--repeat", type=int, choices=(1, 2), required=True)
    p.add_argument("--count", type=int, default=20)
    p.add_argument("--warmup", type=int, default=2)
    p.add_argument("--seed", type=int, default=2026)
    p.add_argument("--rows", type=int, default=3000)
    p.add_argument("--rounds", type=int, default=24)
    p.add_argument("--timeout-ms", type=float, default=1000)
    p.add_argument("--delay-every", type=int, default=0)
    p.add_argument("--delay-ms", type=float, default=0)
    p.add_argument("--out", required=True)
    a = p.parse_args()
    if not (1 <= a.count <= 500 and 0 <= a.warmup <= 10 and 1 <= a.rows <= 100000
            and 1 <= a.rounds <= 200 and 1 <= a.timeout_ms <= 60000
            and 0 <= a.delay_every <= 500 and 0 <= a.delay_ms <= 10000):
        p.error("Параметры вне безопасных диапазонов; см. --help и METHOD.md")
    if (a.delay_every == 0) != (a.delay_ms == 0):
        p.error("Для контролируемой задержки нужны оба --delay-every и --delay-ms")
    out = Path(a.out)
    if out.exists():
        p.error("Каталог результата уже существует. Выберите новое имя; ничего не перезаписано")
    out.mkdir(parents=True)
    rng = random.Random(a.seed)
    values = [rng.randrange(256) for _ in range(a.rows)]
    payload = json.dumps({"values": values}, separators=(",", ":")).encode("utf-8")
    input_path = (out / "input.json").resolve()
    input_path.write_bytes(payload)
    expected = process(values, "B", a.rounds)
    metadata = {"schema": 1, "tool": "p95-local-experiment-1.0", "started_utc":
                datetime.now(timezone.utc).isoformat(), "parameters": vars(a),
                "python": platform.python_version(), "platform": platform.system(),
                "platform_release": platform.release(), "machine": platform.machine(),
                "logical_cpus": os.cpu_count(), "clock": "perf_counter_ns",
                "clock_resolution_s": time.get_clock_info("perf_counter").resolution,
                "input_sha256": hashlib.sha256(payload).hexdigest(),
                "workload_sha256": hashlib.sha256((ROOT / "starter/workload.py").read_bytes()).hexdigest(),
                "expected_result": expected, "state": "running",
                "timing_scope": "parent wall time: spawn, load, work, output, process exit",
                "timeout_scope": "subprocess.run communicate timeout after process creation"}
    meta = out / "run.json"
    meta.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        with (out / "raw.csv").open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=FIELDS)
            writer.writeheader()
            for index in range(a.warmup + a.count):
                phase = "warmup" if index < a.warmup else "measured"
                measured_index = index - a.warmup + 1
                delay = a.delay_ms if phase == "measured" and a.delay_every and measured_index % a.delay_every == 0 else 0
                command = [sys.executable, str(ROOT / "worker.py"), "--input", str(input_path),
                           "--mode", a.mode, "--rounds", str(a.rounds), "--delay-ms", str(delay)]
                status, duration, wait, result, error = once(command, a.timeout_ms)
                if status == "ok" and result != expected:
                    status, duration, error = "error", "", "result mismatch"
                writer.writerow({"attempt": index + 1, "phase": phase, "mode": a.mode,
                    "repeat": a.repeat, "status": status,
                    "duration_ms": round(duration, 6) if duration != "" else "",
                    "observed_wait_ms": round(wait, 6), "timeout_ms": a.timeout_ms,
                    "injected_delay_ms": delay, "result": result, "error": error})
                handle.flush()
                print(f"{phase} {index + 1}: {status}; observed wait {wait:.3f} ms")
    except KeyboardInterrupt:
        metadata["state"] = "interrupted"
        meta.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
        print("Прервано. Частичные данные сохранены, не выдавайте их за полный прогон.", file=sys.stderr)
        return 130
    metadata["state"] = "complete"
    metadata["finished_utc"] = datetime.now(timezone.utc).isoformat()
    meta.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Сохранены {out / 'raw.csv'} и {meta}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
