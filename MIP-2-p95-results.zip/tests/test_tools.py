import sys
import unittest
from analysis import nearest_rank
from measure import once
from starter.workload import process

class ToolChecks(unittest.TestCase):
    def test_configs_have_same_result(self):
        for data in ([1, 2, 1], [0] * 50, list(range(30))):
            self.assertEqual(process(data, "A", 3), process(data, "B", 3))
    def test_input_unchanged(self):
        data = [2, 1, 2]
        before = data.copy()
        process(data, "B", 2)
        self.assertEqual(data, before)
    def test_rank(self):
        self.assertEqual(nearest_rank(list(range(1, 21))), 19)
        self.assertIsNone(nearest_rank([]))
    def test_real_process_timeout(self):
        status, duration, wait, _, _ = once([sys.executable, "-c", "import time; time.sleep(2)"], 50)
        self.assertEqual(status, "timeout")
        self.assertEqual(duration, "")
        self.assertGreater(wait, 0)
    def test_real_process_success(self):
        result = once([sys.executable, "-c", "import json; print(json.dumps(dict(result='ok')))"], 3000)
        self.assertEqual(result[0], "ok")
        self.assertEqual(result[3], "ok")

if __name__ == "__main__":
    unittest.main()
