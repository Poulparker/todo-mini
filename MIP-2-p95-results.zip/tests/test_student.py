"""Необязательное место для собственных проверок инструмента и гипотез."""
import unittest

class StudentChecks(unittest.TestCase):
    pass
