import argparse
import json
import sys
from analysis import summarize

def main():
    p = argparse.ArgumentParser(description="Сводка собственных прогонов, без автоматического вердикта")
    p.add_argument("directories", nargs="+")
    a = p.parse_args()
    try:
        result = [summarize(d) for d in a.directories]
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (OSError, ValueError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
