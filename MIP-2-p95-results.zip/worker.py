"""Отдельный процесс одного запроса. Режим задержки нужен для timeout-контроля."""
import argparse
import json
import time
from pathlib import Path
from starter.workload import process

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True)
    p.add_argument("--mode", choices=("A", "B"), required=True)
    p.add_argument("--rounds", type=int, required=True)
    p.add_argument("--delay-ms", type=float, default=0)
    a = p.parse_args()
    values = json.loads(Path(a.input).read_text(encoding="utf-8"))["values"]
    if a.delay_ms:
        time.sleep(a.delay_ms / 1000)
    print(json.dumps({"result": process(values, a.mode, a.rounds)}))

if __name__ == "__main__":
    main()
