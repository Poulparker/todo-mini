"""Готовый измерительный инструмент, не готовые результаты эксперимента."""
import csv
import json
import math
from pathlib import Path

def nearest_rank(values):
    if not values:
        return None
    return sorted(values)[math.ceil(0.95 * len(values)) - 1]

def summarize(directory):
    directory = Path(directory)
    meta = json.loads((directory / "run.json").read_text(encoding="utf-8"))
    with (directory / "raw.csv").open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if meta.get("state") != "complete":
        raise ValueError("Прогон не завершён")
    measured = [r for r in rows if r["phase"] == "measured"]
    if len(measured) != meta["parameters"]["count"]:
        raise ValueError("Число попыток не совпадает с планом")
    success, timeouts, errors = [], 0, 0
    for row in measured:
        if row["status"] == "ok":
            value = float(row["duration_ms"])
            if not math.isfinite(value) or value < 0 or row["result"] != meta["expected_result"]:
                raise ValueError("Некорректное измерение или результат")
            success.append(value)
        elif row["status"] == "timeout":
            if row["duration_ms"]:
                raise ValueError("У timeout не должно быть точной длительности ответа")
            timeouts += 1
        elif row["status"] == "error":
            errors += 1
        else:
            raise ValueError("Неизвестный статус")
    total = len(measured)
    return {"run": directory.name, "mode": meta["parameters"]["mode"],
            "repeat": meta["parameters"]["repeat"], "n_total": total,
            "n_success": len(success), "n_timeout": timeouts, "n_error": errors,
            "timeout_fraction": timeouts / total, "error_fraction": errors / total,
            "p95_success_ms": nearest_rank(success), "nearest_rank": math.ceil(.95 * len(success)) if success else None,
            "p95_all_attempts_ms": nearest_rank(success) if len(success) == total else None,
            "all_attempt_scope": "complete_sample" if len(success) == total else "not_reported_incomplete_observations",
            "input_sha256": meta["input_sha256"], "workload_sha256": meta["workload_sha256"]}
